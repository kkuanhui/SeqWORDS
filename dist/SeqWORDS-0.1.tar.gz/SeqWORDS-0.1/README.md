# SeqWORDS
This is python SeqWORDS package.</br>
SeqWORDS is an unsupervised Chinese word segmentation method.
